package java_reglog;

/**
 *
 * @author  */
public class Java_RegLog {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LoginForm   LoginFormFrame = new LoginForm();
        LoginFormFrame.setVisible(true);
        LoginFormFrame.pack();
        LoginFormFrame.setLocationRelativeTo(null);
        // TODO code application logic here
    }
    
}

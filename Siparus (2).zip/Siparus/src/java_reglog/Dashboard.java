package java_reglog;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;

public class Dashboard extends JFrame {
    // Komponen-komponen UI
    private JPanel headerPanel;
    private JButton logoutButton;

    private JPanel sidebarPanel;
    private JButton dashboardButton;
    private JButton dataPasienButton;
    private JButton dataPerawatButton;
    private JButton dataRuanganButton;

    private JPanel contentPanel;

    public Dashboard() {
        setTitle("SIPARU - Sistem Informasi Pasien dan Ruangan");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLayout(new BorderLayout());

        // Header
        headerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        headerPanel.setBackground(new Color(144, 238, 144));
        headerPanel.setPreferredSize(new Dimension(800, 50));
        JLabel headerLabel = new JLabel("Dashboard SIPARU");
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        logoutButton = new JButton("Logout");
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setBackground(new Color(220, 20, 60));
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Aksi logout, mengarahkan ke halaman login
                JOptionPane.showMessageDialog(null, "Anda berhasil logout.");
                dispose(); // Menutup dashboard
                Login login = new Login();
                login.showLogoutMessage(); // Buka halaman login
            }
        });
        headerPanel.add(headerLabel);
        headerPanel.add(logoutButton);

        add(headerPanel, BorderLayout.NORTH);

        // Sidebar
        sidebarPanel = new JPanel();
        sidebarPanel.setLayout(new GridLayout(5, 1));
        sidebarPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK)); // Border untuk sidebar

        // Logo (Gambar)
        ImageIcon logoIcon = new ImageIcon("java_reglog/Horizon.jpg");
        JLabel logoLabel = new JLabel(logoIcon);
        sidebarPanel.add(logoLabel);

        // Tombol-tombol sidebar
        dashboardButton = new JButton("Dashboard");
        dashboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showDashboardPage();
            }
        });
        dashboardButton.setBackground(new Color(144, 238, 144));
        sidebarPanel.add(dashboardButton);

        dataPasienButton = new JButton("Data Pasien");
        dataPasienButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showDataPasienPage();
            }
        });
        dataPasienButton.setBackground(new Color(144, 238, 144));
        sidebarPanel.add(dataPasienButton);

        dataPerawatButton = new JButton("Data Perawat");
        dataPerawatButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showDataPerawatPage();
            }
        });
        dataPerawatButton.setBackground(new Color(144, 238, 144));
        sidebarPanel.add(dataPerawatButton);

        dataRuanganButton = new JButton("Data Ruangan");
        dataRuanganButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showDataRuanganPage();
            }
        });
        dataRuanganButton.setBackground(new Color(144, 238, 144));
        sidebarPanel.add(dataRuanganButton);

        add(sidebarPanel, BorderLayout.WEST);

        // Halaman Tengah (Content)
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        JLabel contentLabel = new JLabel("Halaman Utama", SwingConstants.CENTER);
        contentPanel.add(contentLabel, BorderLayout.CENTER);

        add(contentPanel, BorderLayout.CENTER);

        // Tampilkan halaman dashboard saat aplikasi dimulai
        showDashboardPage();
    }

    private void showDashboardPage() {
        contentPanel.removeAll();
        
        // Panel untuk menampung tombol-tombol informasi
        JPanel infoPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Tombol jumlah pasien
        JButton jumlahPasienButton = new JButton("Jumlah Pasien: 100");
        jumlahPasienButton.setBackground(new Color(144, 238, 144));
        jumlahPasienButton.setPreferredSize(new Dimension(150, 75));
        jumlahPasienButton.setEnabled(false);
        infoPanel.add(jumlahPasienButton);

        // Tombol jumlah ruangan kosong
        JButton jumlahRuanganKosongButton = new JButton("Jumlah Ruangan Kosong: 20");
        jumlahRuanganKosongButton.setBackground(new Color(144, 238, 144));
        jumlahRuanganKosongButton.setPreferredSize(new Dimension(150, 75));
        jumlahRuanganKosongButton.setEnabled(false);
        infoPanel.add(jumlahRuanganKosongButton);

        // Tombol jumlah perawat
        JButton jumlahPerawatButton = new JButton("Jumlah Perawat: 50");
        jumlahPerawatButton.setBackground(new Color(144, 238, 144));
        jumlahPerawatButton.setPreferredSize(new Dimension(150, 75));
        jumlahPerawatButton.setEnabled(false);
        infoPanel.add(jumlahPerawatButton);

        contentPanel.add(infoPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showDataPasienPage() {
        contentPanel.removeAll();
        
        String[] columnNames = {"ID", "Nama", "Usia", "Alamat"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addButton = new JButton("Tambah");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Hapus");

        addButton.addActionListener(e -> {
            JPanel formPanel = new JPanel(new GridLayout(0, 2));
            JTextField namaField = new JTextField();
            JTextField usiaField = new JTextField();
            JTextField alamatField = new JTextField();
            formPanel.add(new JLabel("Nama:"));
            formPanel.add(namaField);
            formPanel.add(new JLabel("Usia:"));
            formPanel.add(usiaField);
            formPanel.add(new JLabel("Alamat:"));
            formPanel.add(alamatField);

            int result = JOptionPane.showConfirmDialog(null, formPanel, "Tambah Pasien", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                model.addRow(new Object[]{model.getRowCount() + 1, namaField.getText(), Integer.parseInt(usiaField.getText()), alamatField.getText()});
            }
        });

        updateButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                JPanel formPanel = new JPanel(new GridLayout(0, 2));
                JTextField namaField = new JTextField((String) model.getValueAt(selectedRow, 1));
                JTextField usiaField = new JTextField(String.valueOf(model.getValueAt(selectedRow, 2)));
                JTextField alamatField = new JTextField((String) model.getValueAt(selectedRow, 3));
                formPanel.add(new JLabel("Nama:"));
                formPanel.add(namaField);
                formPanel.add(new JLabel("Usia:"));
                formPanel.add(usiaField);
                formPanel.add(new JLabel("Alamat:"));
                formPanel.add(alamatField);

                int result = JOptionPane.showConfirmDialog(null, formPanel, "Update Pasien", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    model.setValueAt(namaField.getText(), selectedRow, 1);
                    model.setValueAt(Integer.parseInt(usiaField.getText()), selectedRow, 2);
                    model.setValueAt(alamatField.getText(), selectedRow, 3);
                }
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                model.removeRow(selectedRow);
            }
        });

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showDataPerawatPage() {
        contentPanel.removeAll();
        
        String[] columnNames = {"ID", "Nama", "Spesialis", "Telepon"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addButton = new JButton("Tambah");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Hapus");

        addButton.addActionListener(e -> {
            JPanel formPanel = new JPanel(new GridLayout(0, 2));
            JTextField namaField = new JTextField();
            JTextField spesialisField = new JTextField();
            JTextField teleponField = new JTextField();
            formPanel.add(new JLabel("Nama:"));
            formPanel.add(namaField);
            formPanel.add(new JLabel("Spesialis:"));
            formPanel.add(spesialisField);
            formPanel.add(new JLabel("Telepon:"));
            formPanel.add(teleponField);

            int result = JOptionPane.showConfirmDialog(null, formPanel, "Tambah Perawat", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                model.addRow(new Object[]{model.getRowCount() + 1, namaField.getText(), spesialisField.getText(), teleponField.getText()});
            }
        });

        updateButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                JPanel formPanel = new JPanel(new GridLayout(0, 2));
                JTextField namaField = new JTextField((String) model.getValueAt(selectedRow, 1));
                JTextField spesialisField = new JTextField((String) model.getValueAt(selectedRow, 2));
                JTextField teleponField = new JTextField((String) model.getValueAt(selectedRow, 3));
                formPanel.add(new JLabel("Nama:"));
                formPanel.add(namaField);
                formPanel.add(new JLabel("Spesialis:"));
                formPanel.add(spesialisField);
                formPanel.add(new JLabel("Telepon:"));
                formPanel.add(teleponField);

                int result = JOptionPane.showConfirmDialog(null, formPanel, "Update Perawat", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    model.setValueAt(namaField.getText(), selectedRow, 1);
                    model.setValueAt(spesialisField.getText(), selectedRow, 2);
                    model.setValueAt(teleponField.getText(), selectedRow, 3);
                }
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                model.removeRow(selectedRow);
            }
        });

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showDataRuanganPage() {
        contentPanel.removeAll();
        
        String[] columnNames = {"ID", "Nama Ruangan", "Kapasitas", "Lokasi"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addButton = new JButton("Tambah");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Hapus");

        addButton.addActionListener(e -> {
            JPanel formPanel = new JPanel(new GridLayout(0, 2));
            JTextField namaField = new JTextField();
            JTextField kapasitasField = new JTextField();
            JTextField lokasiField = new JTextField();
            formPanel.add(new JLabel("Nama Ruangan:"));
            formPanel.add(namaField);
            formPanel.add(new JLabel("Kapasitas:"));
            formPanel.add(kapasitasField);
            formPanel.add(new JLabel("Lokasi:"));
            formPanel.add(lokasiField);

            int result = JOptionPane.showConfirmDialog(null, formPanel, "Tambah Ruangan", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                model.addRow(new Object[]{model.getRowCount() + 1, namaField.getText(), Integer.parseInt(kapasitasField.getText()), lokasiField.getText()});
            }
        });

        updateButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                JPanel formPanel = new JPanel(new GridLayout(0, 2));
                JTextField namaField = new JTextField((String) model.getValueAt(selectedRow, 1));
                JTextField kapasitasField = new JTextField(String.valueOf(model.getValueAt(selectedRow, 2)));
                JTextField lokasiField = new JTextField((String) model.getValueAt(selectedRow, 3));
                formPanel.add(new JLabel("Nama Ruangan:"));
                formPanel.add(namaField);
                formPanel.add(new JLabel("Kapasitas:"));
                formPanel.add(kapasitasField);
                formPanel.add(new JLabel("Lokasi:"));
                formPanel.add(lokasiField);

                int result = JOptionPane.showConfirmDialog(null, formPanel, "Update Ruangan", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    model.setValueAt(namaField.getText(), selectedRow, 1);
                    model.setValueAt(Integer.parseInt(kapasitasField.getText()), selectedRow, 2);
                    model.setValueAt(lokasiField.getText(), selectedRow, 3);
                }
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                model.removeRow(selectedRow);
            }
        });

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Dashboard().setVisible(true);
            }
        });
    }
}

package java_reglog;

import java.sql.*;

public class dataPasien {
    // Informasi koneksi ke database
    private String jdbcURL = "jdbc:mysql://localhost:3306/siparu";
    private String username = "root";
    private String password = "your_password"; // Ganti dengan password MySQL Anda

    private Connection connection;

    public dataPasien() {
        try {
            // Membuat koneksi ke database
            connection = DriverManager.getConnection(jdbcURL, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method untuk menambahkan data pasien ke tabel pasien
    public void createPasien(String namaPasien, String alamat, String ruangan) {
        String sql = "INSERT INTO pasien (nama_pasien, alamat, ruangan) VALUES (?, ?, ?)";

        try (java_reglog.PreparedStatement statement = (PreparedStatement) connection.prepareStatement(sql)) {
            statement.setString(1, namaPasien);
            statement.setString(2, alamat);
            statement.setString(3, ruangan);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Data pasien berhasil ditambahkan.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method untuk membaca data pasien dari tabel pasien
    public void readPasien() {
        String sql = "SELECT * FROM pasien";

        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(sql)) {

            while (result.next()) {
                int idPasien = result.getInt("id_pasien");
                String namaPasien = result.getString("nama_pasien");
                String alamat = result.getString("alamat");
                String ruangan = result.getString("ruangan");

                System.out.println("ID: " + idPasien + ", Nama: " + namaPasien + ", Alamat: " + alamat + ", Ruangan: " + ruangan);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method untuk mengupdate data pasien di tabel pasien
    public void updatePasien(int idPasien, String namaPasien, String alamat, String ruangan) {
        String sql = "UPDATE pasien SET nama_pasien = ?, alamat = ?, ruangan = ? WHERE id_pasien = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, namaPasien);
            statement.setString(2, alamat);
            statement.setString(3, ruangan);
            statement.setInt(4, idPasien);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Data pasien dengan ID " + idPasien + " berhasil diupdate.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method untuk menghapus data pasien dari tabel pasien
    public void deletePasien(int idPasien) {
        String sql = "DELETE FROM pasien WHERE id_pasien = ?";

        try (java_reglog.PreparedStatement statement = (PreparedStatement) connection.prepareStatement(sql)) {
            statement.setInt(1, idPasien);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Data pasien dengan ID " + idPasien + " berhasil dihapus.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        dataPasien dp = new dataPasien();

        // Contoh operasi CRUD
        // 1. Menambahkan data pasien
        dp.createPasien("John Doe", "Jl. Sudirman No. 123", "Ruangan A");

        // 2. Membaca data pasien
        dp.readPasien();

        // 3. Mengupdate data pasien
        dp.updatePasien(1, "Jane Smith", "Jl. Gatot Subroto No. 456", "Ruangan B");

        // 4. Menghapus data pasien
        dp.deletePasien(2);
    }
}
